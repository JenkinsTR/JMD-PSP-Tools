pmf maker 0.2 by piccahoe (http://piccahoe.phase1media.com)

requirements:
Sony's UMD tools
Virual Dub: see Darkstone's tutorial.
DarkStone Wonderful tutorial (included)


note: I did not program this program for competition. I just wanted to see if I could do something like this and share it with everyone who
needs it.

source code included! (programmed in C and ASM)

*new*
-windows GUI (no more dos)
-You can now name your save pmf file.
-You can now edit the mins and secs
-Create Icons for your game

NOTE: IF YOU WANT TO CREATE AN ICON FOR YOUR GAME, YOU MUST ENCODE THE VIDEO WITH 144 x 80 resulution!!!

Failed attempt:
I don't think its possible to make a pmf file with max resulution. (780x420)

next version (?)
-Change the Screen size
-Change the FPS and Secs ( I don't if it matters tho)
???

thanks: Darkstone and everybody at QJ.net's psp forums.