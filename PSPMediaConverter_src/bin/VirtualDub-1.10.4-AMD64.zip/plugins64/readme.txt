Filter plugins (*.vdf) placed here are automatically loaded
by the 64-bit version of VirtualDub on startup.
