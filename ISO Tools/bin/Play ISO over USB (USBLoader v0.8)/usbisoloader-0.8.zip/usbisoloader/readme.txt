USB ISO Loader v0.8
by psp.padawan

This program will allow you to play your backup games from your pc via USB.  It is based on SDK sample programs provided by Dark_AleX. It uses OE no-umd mode not np9660. It will use OE no-umd mode regardless of what no-umd mode is set in recovery. If your backup games do not load use "UMD required" mode from recovery menu and put a UMD in the drive.  I've tested it on 3.52 M33-4 and 4.01 M33-2 (without 1.5 kernel add-on).  It has also been tested to work with cwcheat 0.2.2.

Supported CFW:

3.52 M33-4
3.71 M33-4
3.80 M33-5
3.90 M33-3
4.01 M33-2

Installation:

Just unzip the usbisoloader folder into your /PSP/GAME folder.  For first time users use the libusb-win32 driver install guide.

Memory Stick Mode:

If you are having issues loading games via USB please try MS mode by doing the following:

- Copy the game you are having a problem loading via USB to your memory stick.
- Disconnect the usb cable.
- Run USB ISO Loader and hold the L-trigger to enable MS mode which will load games off your memory stick. You should see [ms0:/ISO] in the lower left corner of the screen.
- Run your game.
- If the game loads then there is a problem with your usb connection. If the game does not load then USB ISO Loader will not be able to load your game.

I take no credit for this as this was all based on existing code.

Thank you to the following:

Dark_AleX for OE/M33 CFW, SDK and sample codes.
www.ps2dev.org for pspsdk
TyRaNiD for usbhostfs
Sakya for OSLib Mod 1.0.1
juan2320 for game compatibility list
BigGanja and askoman for beta testing

Change History:

0.1
Initial release

0.2
Added debug mode to determine if loading problem is from usb link or USB ISO Loader itself.
Added checking for UMD in drive if "UMD required" mode is selected.

0.3
Now uses Enter button configuration set in recovery.
Fixed error message when run in /PSP/GAME150 or kernel 1.50 is set for /PSP/GAME.
Added check for usbhostfs.prx in usbisoloader folder.

0.5
Fixed normal UMD mode issue ( Thanks to Cpasjuste for helping ).
Added config file for setting text and background colors. ( Thanks to harleyg for getconfig code sample )
Added next/prev page support using left/right d-pad buttons.
Added icon0.png and pic1.png images ( Thanks to nevaskinha and organic ).

0.6
Added png background for game list screen ( Thanks to Chilly Willy for code ).
Added option to display ISO pic1.png or default png on game selection.
Added option to display debug messages while loading game.
Added option to specify a PRX file instead of EBOOT.BIN for games like Beowulf.

0.7
Converted to use OSLib Mod 1.0.1 by Sakya.
Now displays both ISO pic1.png and icon0.png on game selection.
Increased max list to 300.
Added option to write debug output to file.
Now goes back to game list screen on game exit. ( Thanks to Cpasjuste for sample code )
Changed [Debug Mode] to [ms0:/ISO]

0.71
Added option to change usbhostfs pid ( useful for connecting multiple PSPs to one pc )
Fixed issue with hardcoded /PSP/GAME folder location ( will now work on GAME, GAME3XX, or GAME4XX )

0.8
Added check for usbhostfs_pc connection if USB ISO Loader is started first.
Added prx list display if game id has more than one prx specified in gameboot.conf.
Added support for directory browsing.
Added option to specify pc root directory. Default directory is host0:/

