EDecrypt v1.4.0
===============

Based on PSARDumper's sources.
Recompiled and optimized by mc707.

How to use
==========
1. Copy EDecrypt folder to ms0:/PSP/GAME
2. Copy encrypted file(s) to ms0:/enc/
3. Execute EDecrypt on PSP
4. Press X to decrypt file(s) or [] to decrypt and patch file(s) for m33

Version history
===============

1.4.0*
 - added key for tag 0xD91613F0 (Thanks to hrimfaxi)

1.3.2*
 - if output buffer allocation failed, EDecrypt will now try to use unsafe method.
   It may cause unpredictable bugs, but it's better than nothing :)

1.3.1*
 - added signatures for new firmware version checks
 - unencrypted ELF binaries can be patched too
 - added decompression of compressed, but not encrypted files
 - improved memory handling, so now PSPs with 64 MB of RAM can decrypt files up to ~25 MB
 - little bug and typo fixes ;)

1.3*
 - added many keys
 - added 6.10 key
 - patching routine
 - logging to file ms0:/enc/done/log.txt
 - multiple files processing

1.2*
 -added keys for 0xC0CB167C tag
 -improved functionality

1.1*
 -added 6.0 FW keys

Todo list
=========
1. Reorganizing to get rid pspdecrypt.prx
2. Encrypting routine
3. Possible: patching CFW checking

Thanks to
=========
Dark_AleX, Team Noobz, Team C+D, M33 Team, Red Bull PSP team, GEN team, jas0nuk, Yoshihiro,
ErikPshat, and one man who deserved it.

Greetz to
=========
REVENGE Crew, all their ex-members and all russian coders.

������ �� �������. 
--------------------
mc707.int3[at]gmail[dot]com
2010 �.